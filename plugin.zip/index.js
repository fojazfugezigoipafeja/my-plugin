var plugin = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // src/index.ts
  var index_exports = {};
  __export(index_exports, {
    default: () => index_default
  });
  var { metro, patcher } = window.vendetta;
  var { findByProps } = metro;
  var { instead } = patcher;
  var unpatch;
  var index_default = {
    onLoad: () => {
      const UserStore = findByProps("getCurrentUser");
      if (!UserStore) return;
      unpatch = instead("getCurrentUser", UserStore, (args, orig) => {
        const user = orig(...args);
        if (user) {
          return {
            ...user,
            username: "Relapse",
            globalName: "Relapse"
          };
        }
        return user;
      });
    },
    onUnload: () => {
      if (unpatch) unpatch();
    }
  };
  return __toCommonJS(index_exports);
})();
module.exports = plugin.default || plugin;
